#include "bios_timer_int.h"
#include <avr/io.h>
#include <avr/interrupt.h>

#define xtal 16000000L

const static uint8_t prescales[] = {0, 0, 3, 6, 8, 10};
static void (*Timer1_Overflow_function)(void) = 0;

void Timer1_initialize ( uint32_t frequency, void (*handle_overflow)(void), uint8_t prescaler )
{
    Timer1_Overflow_function = handle_overflow;
    TCNT1=0x00;
    OCR1A = ((uint32_t)(xtal)>>prescales[prescaler]) / frequency - 1;
    TCCR1A = 0x00;
    TCCR1B = 0x08 | (0x07 & prescaler);
    TIFR1  = 0;
    TIMSK1 = (1<<OCIE1A);
}

void Timer1_shutdown ()
{
    TIMSK1 &= ~(1<<TOIE1 | 1<<OCIE1A | 1<<OCIE1B | 1<<TOIE1);
    TCCR1A = 0;
    TCCR1B = 0;
    TCCR1C = 0;
    TIMSK1 = 0;
    TIFR1  = 0;
}

ISR(TIMER1_COMPA_vect)
{
    Timer1_Overflow_function();
}
