//* bios_kpads.c *

#include "bios_kpads.h"
#include <avr/io.h>

#define KEY_BOUNCE_CNT (5)

inline void delay_digital_io_change(void)
{
    __asm__ __volatile__("nop");
    __asm__ __volatile__("nop");
    __asm__ __volatile__("nop");
}

inline void setDDRD(uint8_t v)  { DDRD  = (DDRD  & 0x0F) | ( (v<<4) & 0xF0); }
inline void setPORTD(uint8_t v) { PORTD = (PORTD & 0x0F) | ( (v<<4) & 0xF0); }
inline void setDDRC(uint8_t v)  { DDRC  = (DDRC  & 0xF0) | ( v & 0x0F); }
inline void setPORTC(uint8_t v) { PORTC = (PORTC & 0xF0) | ( v & 0x0F); }

inline void rechargeAllLines()  { setDDRD(0b1111); setPORTD(0b1111); setDDRC(0b1111); setPORTC(0b1111); }
inline void disconnectAllLines(){ setDDRD(0b0000); setPORTD(0b0000); setDDRC(0b0000); setPORTC(0b0000); }
inline void SetReadRow()        { setDDRD(0b0000); setPORTD(0b1111); }
inline uint8_t getPINDshifted() { return( (PIND>>4) & 0x0F ); }

char keypressed(void)
{
    uint8_t s_ddrd = DDRD;
    uint8_t s_pord = PORTD;
    uint8_t s_ddrc = DDRC;
    uint8_t s_porc = PORTC;
    uint8_t scanned;
    uint8_t status = KEY_NONE;

    rechargeAllLines();
    delay_digital_io_change();
    SetReadRow(); setDDRC(0b1000); setPORTC(0b0111);
    delay_digital_io_change();
    scanned = 0x0F & ~ getPINDshifted();
    if (scanned && (status!=KEY_NONE) ) {
        status = KEY_MANY;
    } else {
        switch (scanned) {
            case 0b00000000: break;
            case 0b00000001: status = KEY_D;  break; // D
            case 0b00000010: status = KEY_H;  break; // H
            case 0b00000100: status = KEY_0;  break; // 0
            case 0b00001000: status = KEY_S;  break; // S
            default:         status = KEY_MANY;
        }
    }

    rechargeAllLines();
    delay_digital_io_change();
    SetReadRow(); setDDRC(0b0100); setPORTC(0b1011);
    delay_digital_io_change();
    scanned = 0x0F & ~ getPINDshifted();
    if (scanned && (status!=KEY_NONE) ) {
        status = KEY_MANY;
    } else {
        switch (scanned) {
            case 0b00000000: break;
            case 0b00000001: status = KEY_C;  break; // C
            case 0b00000010: status = KEY_9;  break; // 9
            case 0b00000100: status = KEY_8;  break; // 8
            case 0b00001000: status = KEY_7;  break; // 7
            default:         status = KEY_MANY;
        }
    }

    rechargeAllLines();
    delay_digital_io_change();
    SetReadRow(); setDDRC(0b0010); setPORTC(0b1101);
    delay_digital_io_change();
    scanned = 0x0F & ~ getPINDshifted();
    if (scanned && (status!=KEY_NONE) ) {
        status = KEY_MANY;
    } else {
        switch (scanned) {
            case 0b00000000: break;
            case 0b00000001: status = KEY_B;  break; // B
            case 0b00000010: status = KEY_6;  break; // 6
            case 0b00000100: status = KEY_5;  break; // 5
            case 0b00001000: status = KEY_4;  break; // 4
            default:         status = KEY_MANY;
        }
    }

    rechargeAllLines();
    delay_digital_io_change();
    SetReadRow(); setDDRC(0b0001); setPORTC(0b1110);
    delay_digital_io_change();
    scanned = 0x0F & ~ getPINDshifted();
    if (scanned && (status!=KEY_NONE) ) {
        status = KEY_MANY;
    } else {
        switch (scanned) {
            case 0b00000000: break;
            case 0b00000001: status = KEY_A;  break; // A
            case 0b00000010: status = KEY_3;  break; // 3
            case 0b00000100: status = KEY_2;  break; // 2
            case 0b00001000: status = KEY_1;  break; // 1
            default:         status = KEY_MANY;
        }
    }

    DDRD  = s_ddrd;
    PORTD = s_pord;
    DDRC  = s_ddrc;
    PORTC = s_porc;

    return(status);
}

char getkey(void)
{
    uint8_t key_current=KEY_NONE, key_old;
    uint8_t key_cnt=0;
    do {
        key_old     = key_current;
        key_current = keypressed();
        if (key_current==key_old) key_cnt++;
        else key_cnt=0;
    } while (key_current==KEY_NONE||key_current==KEY_MANY||key_cnt<KEY_BOUNCE_CNT);

    while (KEY_NONE!=keypressed()) ;

    return(key_current);
}
